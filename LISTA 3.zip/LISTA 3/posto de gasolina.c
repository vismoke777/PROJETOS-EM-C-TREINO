#include <stdio.h>

int main() {
    float litros, preco, total, desconto;
    char tipo;

    printf("Digite a quantidade de litros: ");
    scanf("%f", &litros);

    printf("Digite o tipo de combustivel (A para alcool, G para gasolina): ");
    scanf(" %c", &tipo);

    if (tipo == 'A' || tipo == 'a') {
        preco = 4.34;
        total = litros * preco;

        if (litros <= 20) {
            desconto = total * 0.03;
            total = total - desconto;
        } else {
            desconto = total * 0.05;
            total = total - desconto;
        }

    } else if (tipo == 'G' || tipo == 'g') {
        preco = 6.77;
        total = litros * preco;

        if (litros <= 20) {
            desconto = total * 0.04;
            total = total - desconto;
        } else {
            desconto = total * 0.06;
            total = total - desconto;
        }

    } else {
        printf("Tipo de combustivel invalido.\n");
        return 0;
    }

    printf("O valor total a ser pago e: %.2f\n", total);

    return 0;
}