#include <stdio.h>
int main() {;
    int main[10]= {1,2,3,4,5,6,7,8,9,10};
    printf("Números ímpares em posição invertida;\n");
    for(int i=9;i>=0;i--){
        if(main[i]%2!=0){
            printf("%d\n", main[i]);
        }
    }
}