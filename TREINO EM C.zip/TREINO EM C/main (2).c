

#include <stdio.h>

int main() {
    int matriz[3][3];
    int i, j;
    int soma = 0;

    for (i = 0; i < 3; i++) {
        for (j = 0; j < 3; j++) {
            printf("Digite o elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);

            soma = soma + matriz[i][j];
        }
    }

    printf("\nSoma de todos os elementos: %d", soma);

    return 0;
}
