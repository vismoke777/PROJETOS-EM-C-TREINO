
#include <stdio.h>

int main() {
    int numeros[10];
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite o %d numero: ", i + 1);
        scanf("%d", &numeros[i]);
    }

    printf("\nNumeros impares em ordem inversa:\n");

    for (i = 9; i >= 0; i--) {
        if (numeros[i] % 2 != 0) {
            printf("%d ", numeros[i]);
        }
    }

    return 0;
}
