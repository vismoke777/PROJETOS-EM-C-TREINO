#include <stdio.h>

int main() {
    int matriz[4][4];
    int i, j;
    int pares = 0;

    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++) {
            printf("Digite o elemento [%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);

            if (matriz[i][j] % 2 == 0) {
                pares++;
            }
        }
    }

    printf("\nQuantidade de numeros pares: %d", pares);

    return 0;
}