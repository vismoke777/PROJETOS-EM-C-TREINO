#include <stdio.h>

int main() {
float media, cargaH;
int faltas;

printf("média do aluno:");
scanf("%f", &media);
    printf("faltas do aluno:");
    scanf("%d", &faltas);
    printf("carga horaria");
    scanf("%f", &cargaH);
    if(media >= 7 && faltas <= (cargaH * 0.15))
    printf("aluno aprovado");
    else
    printf("aluno reprovado");
}
